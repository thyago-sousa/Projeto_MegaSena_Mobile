package br.gov.sp.cps.buttontext;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import java.util.TreeSet;

public class MainActivity extends AppCompatActivity {

    private TextView t1, t2, t3, t4, t5, t6;
    private Button bSortear, bLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setStatusBarColor(Color.parseColor("#191919"));
        getWindow().getDecorView().setSystemUiVisibility(0);
        inicializarComponentes();

        bSortear.setOnClickListener(v -> sortearNumeros());
        bLimpar.setOnClickListener(v -> limparCampos());
    }
    private void inicializarComponentes() {
        t1 = findViewById(R.id.n1);
        t2 = findViewById(R.id.n2);
        t3 = findViewById(R.id.n3);
        t4 = findViewById(R.id.n4);
        t5 = findViewById(R.id.n5);
        t6 = findViewById(R.id.n6);
        bSortear = findViewById(R.id.btnSortear);
        bLimpar = findViewById(R.id.btnLimpar);
    }
    private void sortearNumeros() {
        Random r = new Random();
        TreeSet<Integer> sorteados = new TreeSet<>();
        while (sorteados.size() < 6) {
            sorteados.add(r.nextInt(60) + 1);
        }
        Object[] lista = sorteados.toArray();
        t1.setText(String.format("%02d", lista[0]));
        t2.setText(String.format("%02d", lista[1]));
        t3.setText(String.format("%02d", lista[2]));
        t4.setText(String.format("%02d", lista[3]));
        t5.setText(String.format("%02d", lista[4]));
        t6.setText(String.format("%02d", lista[5]));
    }
    private void limparCampos() {
        t1.setText("--");
        t2.setText("--");
        t3.setText("--");
        t4.setText("--");
        t5.setText("--");
        t6.setText("--");
    }
}